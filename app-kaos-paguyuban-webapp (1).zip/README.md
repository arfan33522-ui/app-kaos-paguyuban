# Aplikasi Paguyuban - Data Order & Pembayaran Kaos

Web app ini tampilannya sama persis dengan prototipe yang sudah dibuat, tapi
datanya beneran nyambung ke Google Sheets (bisa dilihat & diedit banyak orang,
otomatis sinkron).

## Cara Deploy (sekitar 20-30 menit)

### Bagian 1 - Pasang backend di Google Sheets

1. Buka spreadsheet **Rekap Kaos Gabungan** (yang ada sheet "Data Peserta").
2. Menu **Extensions -> Apps Script**.
3. Hapus semua isi editor bawaan, lalu copy-paste seluruh isi file `Code.gs`
   (satu folder sama file ini) ke situ.
4. Klik **Deploy -> New deployment**.
5. Klik ikon gear di sebelah "Select type", pilih **Web app**.
6. Isi:
   - Description: bebas, misal "API Rekap Kaos"
   - Execute as: **Me**
   - Who has access: **Anyone**
7. Klik **Deploy**. Google akan minta izin akses (klik Authorize, pilih akun,
   lanjut meski ada peringatan "unsafe" - itu normal karena scriptnya dibuat
   sendiri).
8. Setelah deploy selesai, **copy URL Web App**-nya (bentuknya
   `https://script.google.com/macros/s/xxxxxxx/exec`). Simpan URL ini.

> Catatan: setiap kali Abang **mengubah isi Code.gs**, harus **Deploy -> Manage
> deployments -> edit (pensil) -> New version -> Deploy** lagi supaya
> perubahan kepakai.

### Bagian 2 - Push project ini ke GitHub

1. Buat akun di **github.com** kalau belum punya.
2. Buat repository baru (klik **New**), kasih nama misal `app-kaos-paguyuban`,
   set ke **Public** atau **Private** (bebas), jangan centang apapun
   tambahan, klik **Create repository**.
3. Upload semua file di folder ini ke repo itu. Cara termudah tanpa command
   line: di halaman repo GitHub, klik **Add file -> Upload files**, drag
   semua file & folder (`src/`, `package.json`, `vite.config.js`,
   `index.html`, `.gitignore`), lalu **Commit changes**.

### Bagian 3 - Deploy ke Vercel

1. Buka **vercel.com**, klik **Sign Up**, pilih **Continue with GitHub**
   (login pakai akun GitHub tadi).
2. Di dashboard Vercel, klik **Add New -> Project**.
3. Pilih repo `app-kaos-paguyuban` yang tadi diupload, klik **Import**.
4. Sebelum klik Deploy, buka bagian **Environment Variables**:
   - Name: `VITE_API_URL`
   - Value: URL Web App dari Bagian 1 tadi
   - Klik **Add**
5. Klik **Deploy**. Tunggu 1-2 menit.
6. Setelah selesai, Vercel kasih link publik, contoh:
   `https://app-kaos-paguyuban.vercel.app`

Link itu yang dishare ke warga/pengurus. Setiap orang yang buka akan melihat
data yang sama, dan setiap perubahan status bayar / tambah peserta akan
langsung tersimpan ke Google Sheets aslinya.

## Update tampilan di kemudian hari

Kalau nanti mau ubah tampilan lagi (warna, teks, dll), edit file
`src/App.jsx`, upload ulang perubahannya ke GitHub (commit baru) - Vercel
otomatis re-deploy sendiri setiap ada perubahan di GitHub, tidak perlu setting
ulang dari awal.
